'use strict';
const tls    = require('tls');
const https  = require('https');
const crypto = require('crypto');

const CORS = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

// ============================================================
// SMTP via Gmail TLS (geen externe packages)
// ============================================================

function buildMime({ from, to, cc, subject, text, pdfBase64, pdfFilename }) {
  const b = 'FSB' + Date.now().toString(36).toUpperCase();
  const c76 = s => (s.match(/.{1,76}/g) || []).join('\r\n');
  const lines = [
    `From: FSB Onderhoudsbedrijf <${from}>`,
    `To: ${to}`,
    ...(cc ? [`Cc: ${cc}`] : []),
    `Subject: =?UTF-8?B?${Buffer.from(subject || 'FSB NTA 8025 Rapport').toString('base64')}?=`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${b}"`,
    '',
    `--${b}`,
    'Content-Type: text/plain; charset=utf-8',
    'Content-Transfer-Encoding: base64',
    '',
    c76(Buffer.from(text || '').toString('base64')),
    '',
  ];
  if (pdfBase64) {
    lines.push(
      `--${b}`,
      'Content-Type: application/pdf',
      `Content-Disposition: attachment; filename="${pdfFilename || 'rapport.pdf'}"`,
      'Content-Transfer-Encoding: base64',
      '',
      c76(pdfBase64),
      ''
    );
  }
  lines.push(`--${b}--`);
  return lines.join('\r\n');
}

function smtpSend(opts) {
  return new Promise((resolve, reject) => {
    const { user, pass, to, cc } = opts;
    const email = buildMime({ from: user, to, cc, ...opts });
    const sock = tls.connect({ host: 'smtp.gmail.com', port: 465, servername: 'smtp.gmail.com' });
    let state = 'greeting', buf = '', settled = false;

    const done = err => {
      if (settled) return; settled = true;
      try { sock.destroy(); } catch (_) {}
      err ? reject(err) : resolve(true);
    };
    const w = l => sock.write(l + '\r\n');

    const step = code => {
      switch (state) {
        case 'greeting':  if (code===220){w('EHLO netlify');state='ehlo';} else done(new Error('Greeting: '+code)); break;
        case 'ehlo':      if (code===250){w('AUTH LOGIN');state='auth';} else done(new Error('EHLO: '+code)); break;
        case 'auth':      if (code===334){w(Buffer.from(user).toString('base64'));state='auth_user';} else done(new Error('AUTH: '+code)); break;
        case 'auth_user': if (code===334){w(Buffer.from(pass).toString('base64'));state='auth_pass';} else done(new Error('AUTH user: '+code)); break;
        case 'auth_pass':
          if (code===235){w(`MAIL FROM:<${user}>`);state='mail_from';}
          else if (code===535) done(new Error('Gmail auth mislukt — controleer GMAIL_USER en GMAIL_PASS (app-wachtwoord)'));
          else done(new Error('AUTH pass: '+code)); break;
        case 'mail_from': if (code===250){w(`RCPT TO:<${to}>`);state='rcpt_to';} else done(new Error('MAIL FROM: '+code)); break;
        case 'rcpt_to':
          if (code===250){if(cc){w(`RCPT TO:<${cc}>`);state='rcpt_cc';}else{w('DATA');state='data';}}
          else done(new Error('RCPT TO: '+code)); break;
        case 'rcpt_cc':  if (code===250){w('DATA');state='data';} else done(new Error('RCPT CC: '+code)); break;
        case 'data':     if (code===354){sock.write(email+'\r\n.\r\n');state='body';} else done(new Error('DATA: '+code)); break;
        case 'body':     if (code===250){w('QUIT');state='quit';} else done(new Error('Body geweigerd: '+code)); break;
        case 'quit':     done(null); break;
        default:         done(new Error('Onbekende staat: '+state));
      }
    };

    sock.on('data', chunk => {
      buf += chunk.toString();
      const lines = buf.split('\r\n'); buf = lines.pop();
      for (const l of lines) {
        if (!l || l.length < 3) continue;
        if (l.length > 3 && l[3] === '-') continue;
        step(parseInt(l));
      }
    });
    sock.on('error', done);
    sock.setTimeout(30000, () => done(new Error('SMTP timeout na 30s')));
  });
}

// ============================================================
// Google Drive API via service account (geen externe packages)
// ============================================================

// Generieke HTTPS helper
function httpsReq(options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

// JWT + access token voor service account
async function getDriveToken(sa) {
  const now = Math.floor(Date.now() / 1000);
  const hdr  = Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })).toString('base64url');
  const clm  = Buffer.from(JSON.stringify({
    iss:   sa.client_email,
    scope: 'https://www.googleapis.com/auth/drive.file',
    aud:   'https://oauth2.googleapis.com/token',
    exp:   now + 3600,
    iat:   now
  })).toString('base64url');

  const sign = crypto.createSign('RSA-SHA256');
  sign.update(`${hdr}.${clm}`);
  const sig = sign.sign(sa.private_key, 'base64url');
  const jwt = `${hdr}.${clm}.${sig}`;

  const body = Buffer.from(
    `grant_type=${encodeURIComponent('urn:ietf:params:oauth:grant-type:jwt-bearer')}&assertion=${encodeURIComponent(jwt)}`
  );

  const res = await httpsReq({
    hostname: 'oauth2.googleapis.com',
    path: '/token',
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': body.length }
  }, body);

  const json = JSON.parse(res.body);
  if (!json.access_token) throw new Error('Drive token fout: ' + res.body.slice(0, 200));
  return json.access_token;
}

// Zoek of maak de map "FSB Rapporten"
async function ensureFolder(token, name) {
  const q = encodeURIComponent(`name='${name}' and mimeType='application/vnd.google-apps.folder' and trashed=false`);
  const search = await httpsReq({
    hostname: 'www.googleapis.com',
    path: `/drive/v3/files?q=${q}&fields=files(id,name)&pageSize=1`,
    method: 'GET',
    headers: { Authorization: 'Bearer ' + token }
  });

  const found = JSON.parse(search.body);
  if (found.files && found.files.length > 0) return found.files[0].id;

  // Maak nieuwe map aan
  const meta = Buffer.from(JSON.stringify({ name, mimeType: 'application/vnd.google-apps.folder' }));
  const created = await httpsReq({
    hostname: 'www.googleapis.com',
    path: '/drive/v3/files?fields=id',
    method: 'POST',
    headers: {
      Authorization: 'Bearer ' + token,
      'Content-Type': 'application/json',
      'Content-Length': meta.length
    }
  }, meta);

  const createdJson = JSON.parse(created.body);
  if (!createdJson.id) throw new Error('Map aanmaken mislukt: ' + created.body.slice(0, 200));
  return createdJson.id;
}

// Upload PDF naar Drive (multipart)
async function driveUpload(token, pdfBase64, filename, folderId) {
  const boundary = 'FSBRPT' + Date.now().toString(36).toUpperCase();
  const pdfBuf   = Buffer.from(pdfBase64, 'base64');
  const metaStr  = JSON.stringify({ name: filename, parents: [folderId], mimeType: 'application/pdf' });

  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metaStr}\r\n--${boundary}\r\nContent-Type: application/pdf\r\n\r\n`),
    pdfBuf,
    Buffer.from(`\r\n--${boundary}--`)
  ]);

  const res = await httpsReq({
    hostname: 'www.googleapis.com',
    path: '/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
    method: 'POST',
    headers: {
      Authorization: 'Bearer ' + token,
      'Content-Type': `multipart/related; boundary="${boundary}"`,
      'Content-Length': body.length
    }
  }, body);

  const json = JSON.parse(res.body);
  if (!json.id) throw new Error('Drive upload mislukt (HTTP ' + res.status + '): ' + res.body.slice(0, 200));
  return json;
}

// Hoofd Drive upload functie
async function saveToDrive(pdfBase64, filename) {
  const keyB64 = process.env.GDRIVE_SA_KEY;
  if (!keyB64) return null;

  let sa;
  try { sa = JSON.parse(Buffer.from(keyB64, 'base64').toString('utf8')); }
  catch (e) { throw new Error('GDRIVE_SA_KEY ongeldig JSON: ' + e.message); }

  const token    = await getDriveToken(sa);
  const folderId = await ensureFolder(token, 'FSB Rapporten');
  return await driveUpload(token, pdfBase64, filename, folderId);
}

// ============================================================
// HANDLER
// ============================================================

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS, body: '{}' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  try {
    const { subject, message, pdfBase64, filename } = JSON.parse(event.body || '{}');
    const user = process.env.GMAIL_USER;
    const pass = process.env.GMAIL_PASS;

    if (!user || !pass) {
      throw new Error('Stel GMAIL_USER en GMAIL_PASS in als omgevingsvariabelen op Netlify (Site settings → Environment variables)');
    }

    // 1. Verstuur email via Gmail SMTP
    await smtpSend({
      user, pass,
      to: 'Staedion.mutatie@rendon.nl',
      cc: user,
      subject,
      text: message,
      pdfBase64,
      pdfFilename: filename
    });

    const ts = new Date().toLocaleString('nl-NL', { timeZone: 'Europe/Amsterdam' });
    console.log(`[EMAIL] ${ts} | Verstuurd: ${filename || 'rapport'} → Staedion.mutatie@rendon.nl + CC ${user}`);

    // 2. Sla op in Google Drive (optioneel — alleen als GDRIVE_SA_KEY is ingesteld)
    let driveResult = null;
    if (pdfBase64 && process.env.GDRIVE_SA_KEY) {
      try {
        driveResult = await saveToDrive(pdfBase64, filename || 'rapport.pdf');
        console.log(`[DRIVE] ${ts} | Opgeslagen: ${driveResult.name} | id: ${driveResult.id} | ${driveResult.webViewLink}`);
      } catch (driveErr) {
        // Drive fout is niet fataal — email is al verstuurd
        console.error(`[DRIVE] ${ts} | Fout bij opslaan: ${driveErr.message}`);
      }
    }

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({
        success: true,
        drive: driveResult ? { id: driveResult.id, link: driveResult.webViewLink } : null
      })
    };

  } catch (err) {
    console.error('[FOUT]', err.message);
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: err.message }) };
  }
};
